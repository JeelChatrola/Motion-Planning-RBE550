## Dependencies and Versions

python=3.8.10
matplotlib=3.3.4
numpy=1.19.5

To recreate the results run the rrt.py file.
To modify the arena/obstacles/target change the variables in env.py
Other Details are self-explanatory based on comments in the RRT.py file and env.py files